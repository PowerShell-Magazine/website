# Sort CollectionView when a column header is clicked
# http://msdn.microsoft.com/en-us/library/ms745786
Add-EventHandler -Input $this -EventName Click `
                 -SourceType GridViewColumnHeader {
   $Source = $_.OriginalSource
   if($Source -and $Source.Role -ne "Padding") {
      # Use variables for types (because of line wrapping)
      $tCVS = [System.Windows.Data.CollectionViewSource]
      $tSD = "System.ComponentModel.SortDescription"

      # We need to sort by a PROPERTY of the objects 
      # so just use the path that we used for binding!
      $Prop = $Source.Column.DisplayMemberBinding.Path.Path
      
      # Change the sort direction each time they sort
      $Desc = if($Prop -ne $last){ $true } else { !$Desc }      
      $Dir = if($Desc) { "Descending" } else { "Ascending" }
      $last = $Prop

      # And now we actually apply the sort to the View
      $vw = $tCVS::GetDefaultView($this.ItemsSource)
      $vw.SortDescriptions.Clear()
      $vw.SortDescriptions.Add((New-Object $tSD $Prop,$Dir))
      $vw.Refresh()
   }
}
