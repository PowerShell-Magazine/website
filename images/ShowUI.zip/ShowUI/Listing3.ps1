# Sort ObservableCollection when a column header is clicked
Add-EventHandler -Input $this -EventName Click `
                          -SourceType GridViewColumnHeader {
   $Source = $_.OriginalSource
   if($Source -and $Source.Role -ne "Padding") {
      # We need to sort by a PROPERTY of the objects 
      # so just use the path that we used for binding!
      $Prop = $Source.Column.DisplayMemberBinding.Path.Path
      
      # Change the sort direction each time they sort
      $Desc = if($Prop -ne $last){ $true } else { !$Desc }
      $last = $Prop
      
      # Reassign the ItemsSource after sorting the data
      $this.ItemsSource = $this.ItemsSource | 
         Sort-Object $Prop -Descending:$Desc
   }
}
   