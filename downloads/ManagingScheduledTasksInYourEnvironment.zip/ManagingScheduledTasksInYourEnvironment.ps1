function Get-ScheduledTask 
{
    [CmdletBinding()]
    
    param(  
        [Parameter(
        Mandatory=$true, 
        ValueFromPipeline=$true,
        ValueFromPipelineByPropertyName=$true)]
        [String[]]$ComputerName,  

        [Parameter(Mandatory=$false)]
        [String[]]$RunAsUser,
     
        [Parameter(Mandatory=$false)]
        [String[]]$TaskName,

        [parameter(Mandatory=$false)]
        [alias("WS")]
        [switch]$WithSpace
     )
 
    Begin 
    {
        
        $Script:Tasks = @()
    }

    Process 
    {  
        $schtask = schtasks.exe /query /s $ComputerName  /V /FO CSV | ConvertFrom-Csv
        Write-Verbose  "Getting scheduled Tasks from: $ComputerName" 
        
        if ($schtask) 
        {
            foreach ($sch in $schtask) 
            {
                if ($sch."Run As User" -match "$($RunAsUser)" -and $sch.TaskName -match "$($TaskName)") 
                {
                    Write-Verbose  "$Computername ($sch.TaskName).replace('\','') $sch.'Run As User'"
                    $sch  | Get-Member -MemberType Properties | ForEach -Begin {$hash=@{}} -Process {
                        If ($WithSpace) 
                        {
                            ($hash.($_.Name)) = $sch.($_.Name)
                        }
                        Else
                        {
                            ($hash.($($_.Name).replace(" ",""))) = $sch.($_.Name)
                        }
                    } -End {
                        $script:Tasks += (New-Object -TypeName PSObject -Property $hash)
                    }                    
		        }
            }
        }
    } 
    
    End 
    {
        $Script:Tasks
    }
}


function Set-ScheduledTask 
{
        [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
        
        param(  
        [Parameter(
            Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)]
        [Alias("HOSTNAME")]
        [String[]]$ComputerName,
  
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)]
        [Alias("Run As User")]
        [String[]]$RunAsUser,
     
        [Parameter(Mandatory=$true)]
        [String[]]$Password,

        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)]
        [String[]]$TaskName 
    )
 

    Process 
    {
        Write-Verbose  "Updating: $($_.'TaskName')"
        if ($pscmdlet.ShouldProcess($computername, "Updating Task: $TaskName ")) 
        {
            Write-Verbose "schtasks.exe /change /s $ComputerName /RU $RunAsUser /RP $Password /TN `"$TaskName`""
            $strcmd = schtasks.exe /change /s "$ComputerName" /RU "$RunAsUser" /RP "$Password" /TN "`"$TaskName`"" 2>&1
            Write-Host $strcmd
        }
    }
}

Function Set-2k8ScheduledTask 
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
    
    param(  
        [Parameter(
            Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)]
        [Alias("HOSTNAME")]
        [String[]]$ComputerName,

        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true)]
        [String[]]$TaskName 
    )

    Begin 
    {
        $ShortDate = [regex]"(?<ShortDate>[0-9]{4}[/.-](?:1[0-2]|0[1-9])[/.-](?:3[01]|[12][0-9]|0[1-9])T(?:2[0-3]|[01][0-9])[:.][0-5][0-9][:.][0-5][0-9])(?<Digits>\.\d*)"
    }
 
    Process 
    {
        $XMLIn = schtasks /query /s $ComputerName /tn $TaskName /xml 
        If (Test-Path "$Env:TEMP\$($TaskName).xml") `
        {
            Remove-Item "$Env:TEMP\$($TaskName).xml"
        }
        
        foreach ($line in $XMLIn)
        {
            If ($line -match "$ShortDate") 
            {
                $line = [regex]::Replace($line, $ShortDate, $($Matches["Shortdate"]))
            }
        
            If ($line.length -gt 1) 
            {
                $line | Out-File -Append -FilePath "$Env:TEMP\$($TaskName).xml"
            }
        }
  
  
        if ($pscmdlet.ShouldProcess($ComputerName, "Fixing Task: $TaskName ")) 
        {
            Write-Verbose "Commandline: schtasks /Create /tn $TaskName /XML $Env:TEMP\$($TaskName).xml /f"
            schtasks /Create /tn $TaskName /XML "$Env:TEMP\$($TaskName).xml" /f
        }
        
        Write-Verbose "Removing $Env:TEMP\$($TaskName).xml"
  
        If (Test-Path "$Env:TEMP\$($TaskName).xml") 
        {
            Remove-Item "$Env:TEMP\$($TaskName).xml"
        }  
    }
}
