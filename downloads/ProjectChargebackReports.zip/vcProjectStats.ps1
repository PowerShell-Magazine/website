#requires -version 2

# Send an array (InputObject) in the body of an email.
function Out-Email {
  param(
    [CmdletBinding()]
    [parameter(Mandatory=$true,ValueFromPipeline=$true)]
    [PSObject[]]$InputObject,
    [parameter(Mandatory=$true)]
    [string]$To,
    [parameter(Mandatory=$true)]
    [string]$From,
    [parameter(Mandatory=$true)]
    [string]$Subject
  )
  
  begin{
#region Global values 1
# These variables are normally retrieved from a central
# repository
    Set-Variable -Name CompanySmtpServer `
            -Value "smtp.mycomp.com"
#endregion
            

# If the $PSEmailServer variable is not set, use the
# corporate value. 
# This the reason why the script doesn�t use 
# Send-MailMessage directly
    $mySmtpServer = $PSEmailServer 
    if(!$mySmtpServer){
      $mySmtpServer = $CompanySmtpServer
    }
    $body = @()
  }
  
  process{
    $body += $_
  }
  
  end{
# Convert the array to a string to be able to assign it
# to the Body property
    Send-MailMessage -To $To -From $From `
         -Subject $Subject -Body ($body | Out-String) `
         -SmtpServer $mySmtpServer 
  }
}

# Load the required snapins
Add-PSSnapin Quest.ActiveRoles.ADManagement
Add-PSSnapin VMware.VimAutomation.Core

# Connect to the vCenter server
Connect-VIServer -Server VC

$metrics = "cpu.usage.average","mem.usage.average"
$from = "vmware.report@mycomp.com"

# Produce a report for the previous day
$finish = (Get-Date -Hour 0 -Minute 0 -Second 0)
$finish = $finish.AddMinutes(-1)
$start = $finish.AddDays(-1)

# Get all VMs that belong to a project
$vms = Get-VM | where {$_.CustomFields["Project"]}

# Retrieve the statistics
$stats = Get-Stat -Entity $vms -Stat $metrics `
   -Start $start -Finish $finish

# Group by project owners
$stats | Group-Object `
   -Property {$_.Entity.CustomFields["ProjectOwner"]} | %{
  $projectOwner = $_.Name
   $user = Get-QADUser -DisplayName $projectOwner
  $emailAddress = $user.Email
  
  $report = @()
# Group by projects  
  $_.Group | Group-Object `
      -Property {$_.Entity.CustomFields["Project"]} | %{
    $project = $_.Name
# Group by virtual machines
    $_.Group | Group-Object `
         -Property {$_.Entity.Name} | %{
      $report += New-Object PSObject -Property @{
        Project = $project
        VMName = $_.Name
        AvgCpu = [Math]::Round(($_.Group | `
            where {$_.MetricId -eq "cpu.usage.average"} |
         Measure-Object -Property Value -Average).Average,1)
        AvgMem = [Math]::Round(($_.Group |
            where {$_.MetricId -eq "mem.usage.average"} |
         Measure-Object -Property Value -Average).Average,1)
      }
    }
  }
  $report | Sort-Object -Property Project,VMName |
  Out-Email -To $emailAddress -From $from `
    -Subject "Daily report Project VMs"
}

Disconnect-VIServer -Server VC
