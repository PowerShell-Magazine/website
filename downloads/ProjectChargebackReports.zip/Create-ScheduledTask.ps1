#requires -version 2

# Function derived from a Scripting Guys post
# Post: Checking for Module Dependencies in Windows
#       PowerShell
# URL: http://goo.gl/msS9F
function Get-MyModule{
  param(
    [string]$Name
  )
  
  process{
    $result = $true
    if(!(Get-Module -Name $Name)){
      if((Get-Module -ListAvailable | %{$_.Name}) `
        -contains $Name){
        try {Import-Module -Name $Name `
          -ErrorAction SilentlyContinue}
        catch{
          Write-Error "Did you 'Unblock' the module files ?"
          $result = $false
        }
      }
      else{
        $result = $false
      }
    }
    $result
  }
}

function Set-TaskPrincipal{
    <#
    .Synopsis
        Adds a principal to a task definition
    .Description
        Adds a principal to a task definition.
        You can create a task definition with New-Task, 
    or use an existing definition from Get-ScheduledTask
    .Example
        New-Task -Disabled |
            Add-TaskTrigger  $EVT[0] |
            Add-TaskAction -Path Calc |
      Set-TaskPrincipal -User $User |
            Register-ScheduledTask "$(Get-Random)" 
    #>
    [CmdletBinding(DefaultParameterSetName="Script")]
    param(
    # The Scheduled Task Definition
    [Parameter(Mandatory=$true, 
        ValueFromPipeline=$true)]
    [__ComObject]
    $Task,
    # The RunAs account
    [Management.Automation.PSCredential]
    $RunAsUser
  )

    begin {
        Set-StrictMode -Off
    }

    process {
        if ($task.Definition) { 
          $Task = $task.Definition
        } 
    $Task.Principal.DisplayName = $RunAsUser.UserName
    $Task.Principal.UserId = $RunAsUser.UserName
    $Task.Principal.LogonType = 1    # TASK_LOGON_PASSWORD
    $Task.Principal.RunLevel = 1    # TASK_RUNLEVEL_HIGHEST
    
    $Task
  }
}

# The creation of the daily scheduled task
function New-DailyScheduledTask{
  param(
    [string]$Server,
    [System.Management.Automation.PSCredential]$Credential,
    [string]$TaskName,
    [string]$Script,
    [string]$Time,
    [switch]$Bit32
  )
  
  process{
#region Global values 1
# These variables are normally retrieved from a central
# repository
    Set-Variable -Name TaskScheduler -Value TaskScheduler
    
    Set-Variable -Name PS64 `
    -Value ("%SystemRoot%\system32\WindowsPowerShell\" +
        "v1.0\powershell.exe")
    Set-Variable -Name PS32 `
    -Value ("%SystemRoot%\syswow64\WindowsPowerShell\" +
        "v1.0\powershell.exe")
#endregion

# Is the TaskScheduler module imported ?
    if(!(Get-MyModule -Name $TaskScheduler)){
      Write-Error ("Can't find module " + $TaskScheduler)
      exit
    }

# Does the Scheduled Task already exist ?
    if(Get-ScheduledTask -Name $TaskName){
      Write-Error `
        "Scheduled task $TaskName already exists on $Server"
      exit 1
    }
    
# Handle 32- and 64-bit scripts
    $path = $PS64
    if($Bit32){$path = $PS32}

# Create the Scheduled Task
    New-Task -ComputerName $scriptServer `
      -Credential $Credential `
      -RunOnlyIfNetworkAvailable |
    Add-TaskTrigger -Daily -At $Time |
    Add-TaskAction -Path $path -Arguments $script `
      -WorkingDirectory "C:\Scripts" |
    Set-TaskPrincipal -RunAsUser $Credential |
      Register-ScheduledTask -Name $TaskName `
        -Credential $Credential
  }
}

#region Global values 2
# These variables are normally retrieved from a central 
# repository

$vcScriptServer = "vc.test.local"
$vcCredentials = Get-Credential `
  -Credential "VC script account"
#endregion

# The Scheduled Task values
New-DailyScheduledTask -Server $vcScriptServer `
  -Credential $vcCredentials `
  -Script "C:\Scripts\vcProjectStats.ps1" `
  -TaskName vcProjectStats `
  -Time "02:00 AM" -Bit32
