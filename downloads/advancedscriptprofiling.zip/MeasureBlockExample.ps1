﻿
function TestScript()
{
	MB {
		$variable = MB { Get-Process } -PassThru
		MB {
			foreach($var in $variable)
			{
				MB {
					$var | Format-Table
				}
			}
		}
	}
}
Measure-Block -Process -ScriptBlock { TestScript }  