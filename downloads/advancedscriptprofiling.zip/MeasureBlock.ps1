﻿
function Push-MeasureBlockScope()
{
	[CmdletBinding()]
	param(
		[Parameter()]
		$MeasureBlock
	)
	
	Begin
	{
		if ($Global:MeasureBlockScope -ne 0)
		{
			$Global:MeasureBlockStack.Peek().Children += $MeasureBlock
			$MeasureBlock.Scope = $Global:MeasureBlockScope
			$Global:MeasureBlockScope++;
		}

		$Global:MeasureBlockStack.Push($MeasureBlock)
	}
}

function Flatten()
{
	$children = $args[0].Children
	
	$items = @($children)
	
	foreach($Child in $children)
	{
		if ($Child -eq $null)
		{
			continue
		}
		$items += Flatten $child
	}
	
	return $items
}

function Pop-MeasureBlockScope()
{
	$Global:MeasureBlockScope--;
	$Global:MeasureBlockStack.Pop()
}

function Get-MeasureBlockScope()
{
	$Global:MeasureBlockScope;
}

function Format-MeasureBlock
{
	[CmdletBinding()]
	param(
		[Parameter(Mandatory=$true, ValueFromPipeline=$true)]
		[PSObject]$MeasureBlock,
		[Parameter()]
		[Switch]$AsTable,
		[Parameter()]
		[Switch]$AsList
	)
	
	Process
	{
		$Flattened = Flatten $Root
	
		if ($AsTable)
		{
			$Flattened | Format-Table -Property Name,Duration,Scope -AutoSize
		}
		
		if ($AsList)
		{
			$Flattened | Format-List -Property Name,Duration,Scope
		}	
        
        if (-not $AsList -and -not $AsTable)
        {
            $Flattened | Format-Wide -Property Name,Duration,Scope
        }
	}
}	

function Get-MeasureBlock()
{
	[CmdletBinding()]
	param(
		[Parameter()]
		[String]$Name,
		[Parameter()]
		[String]$ScopeDepth,
		[Parameter()]
		[Switch]$Current
	)
	
	Begin 
	{
		if ($Current)
		{
			Write-Output ($Global:MeasureBlockStack.Peek())
		}
	}
}

function New-MeasuredBlock
{
	[CmdletBinding()]
	param(
		[Parameter(Mandatory=$true)]
		[String]$Name,
		[Parameter(Mandatory=$true)]
		[System.Management.Automation.InvocationInfo]$InvocationInfo,
		[Parameter()]
		[long]$Duration
	)
	
	Begin 
	{
		$obj = New-Object PsObject
		$obj | Add-Member NoteProperty Name $Name
		$obj | Add-Member NoteProperty InvocationInfo $InvocationInfo
		$obj | Add-Member NoteProperty Duration $Duration
		$obj | Add-Member NoteProperty Scope 0
		$obj | Add-Member NoteProperty Children @()
		Write-Output $obj
	}
}

function Set-ChildMeasuredBlock
{
	[CmdletBinding()]
	param(
		[Parameter(Mandatory=$true)]
		$Parent,
		[Parameter(Mandatory=$true,ValueFromPipeline=$true)]
		$Child
	)
	
	Process 
	{
		$Parent.Children += $Child
	}
}

function Measure-Block
{
	[CmdletBinding()]
	param(
		[Parameter(ValueFromPipeline=$true)]
		[PSObject]$InputValue,
		[Parameter(Position=0)]
		[ScriptBlock]$ScriptBlock,
		[Parameter(Position=1)]
		[string]$BlockName,
		[Parameter()]
		[Switch]$Process,
		[Parameter()]
		[Switch]$PassThru
	)
	
	Begin
	{
		if ($Process)
		{
			if ($Global:MeasureBlockRoot -ne $null)
			{
				Write-Error "Cannot call process in a nested Measure-Block!"
				return
			}

			$Global:MeasureBlockScope = 0
			$Global:MeasureBlockRoot = New-MeasuredBlock -Name "Root" -InvocationInfo $MyInvocation 
			$Global:MeasureBlockStack = New-Object System.Collections.Stack;
			
			Push-MeasureBlockScope $MeasureBlockRoot
			$Global:MeasureBlockScope = 1
		}
		else
		{
			# don't process if we don't have a root
			if ($Global:MeasureBlockRoot -eq $null)
			{
				return
			}
		
			if ([String]::IsNullOrEmpty($BlockName))
			{
				$BlockName = "MEASURE_BLOCK:$($MyInvocation.ScriptLineNumber):$($MyInvocation.OffsetInLine)"
			}
		
			Push-MeasureBlockScope (New-MeasuredBlock -Name $BlockName -InvocationInfo $MyInvocation )
		}
		
		Write-Debug "Start: $((Get-MeasureBlock -Current).Name)"
	
		$Stop = New-Object System.Diagnostics.Stopwatch
		$Stop.Start()
	}
	
	Process
	{
		Write-Debug "Process: $((Get-MeasureBlock -Current).Name)"
	
		# don't process if we don't have a root
		if ($Global:MeasureBlockRoot -eq $null)
		{
			return
		}
	
		if ($ScriptBlock -eq $null)
		{
			if (-not $PassThru -and (Get-MeasureBlockScope) -eq 1)
			{
				$InputValue
			}
			else
			{
				$InputValue | Out-Null
			}
		}
		elseif ($InputValue -eq $null)
		{
			if (-not $PassThru -and (Get-MeasureBlockScope) -eq 1)
			{
				Invoke-Command -ScriptBlock $ScriptBlock | Out-Null
			}
			else
			{
				Invoke-Command -ScriptBlock $ScriptBlock
			}	
		}
		else
		{
			if (-not $PassThru -and (Get-MeasureBlockScope) -eq 1)
			{
				$InputValue | Invoke-Command -ScriptBlock $ScriptBlock | Out-Null
			}
			else
			{
				$InputValue | Invoke-Command -ScriptBlock $ScriptBlock
			}	
		}
	}
	
	End 
	{
		# don't process if we don't have a root
		if ($Global:MeasureBlockRoot -eq $null)
		{
			return
		}
	
		$Stop.Stop()

		Write-Debug "End: $((Get-MeasureBlock -Current).Name)"

		if (-not $Process)
		{
			(Get-MeasureBlock -Current).Duration = $Stop.Elapsed
			Pop-MeasureBlockScope | Out-Null
		}
		else
		{
            if ($PassThru)
            {
                $Global:MeasureBlockResult = $Global:MeasureBlockRoot
            }
            else
            {
                $Global:MeasureBlockRoot
            }
            
            $Global:MeasureBlockRoot.Duration = $Stop.Elapsed
        	$Global:MeasureBlockRoot = $null
		    $Global:MeasureBlockStack = $null
		}
	}
}

New-Alias -Name MB -Value Measure-Block

